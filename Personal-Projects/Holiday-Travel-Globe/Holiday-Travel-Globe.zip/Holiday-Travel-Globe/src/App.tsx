import React, { useEffect, useRef, useState } from "react";
import {
  Camera,
  Upload,
  X,
  Globe,
  Image,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import "./styles.css";

interface Country {
  name: string;
  lat: number;
  lng: number;
}

interface Photo {
  url: string;
  name: string;
  date: string;
}

interface CountryPhotos {
  [country: string]: Photo[];
}

const App: React.FC = () => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const globeRef = useRef<THREE.Mesh | null>(null);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [countryPhotos, setCountryPhotos] = useState<CountryPhotos>({});
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);

  const countries: Country[] = [
    { name: "United States", lat: 37.09, lng: -95.71 },
    { name: "United Kingdom", lat: 55.37, lng: -3.43 },
    { name: "France", lat: 46.22, lng: 2.21 },
    { name: "Germany", lat: 51.16, lng: 10.45 },
    { name: "Italy", lat: 41.87, lng: 12.56 },
    { name: "Spain", lat: 40.46, lng: -3.74 },
    { name: "Japan", lat: 36.2, lng: 138.25 },
    { name: "China", lat: 35.86, lng: 104.19 },
    { name: "Australia", lat: -25.27, lng: 133.77 },
    { name: "Brazil", lat: -14.23, lng: -51.92 },
    { name: "Canada", lat: 56.13, lng: -106.34 },
    { name: "India", lat: 20.59, lng: 78.96 },
    { name: "Russia", lat: 61.52, lng: 105.31 },
    { name: "Mexico", lat: 23.63, lng: -102.55 },
    { name: "South Africa", lat: -30.55, lng: 22.93 },
    { name: "Egypt", lat: 26.82, lng: 30.8 },
    { name: "Thailand", lat: 15.87, lng: 100.99 },
    { name: "Greece", lat: 39.07, lng: 21.82 },
    { name: "Turkey", lat: 38.96, lng: 35.24 },
    { name: "Argentina", lat: -38.41, lng: -63.61 },
  ];

  useEffect(() => {
    const THREE = (window as any).THREE;
    if (!THREE || !mountRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0e27);
    sceneRef.current = scene;

    // Camera setup
    const camera = new THREE.PerspectiveCamera(
      75,
      mountRef.current.clientWidth / mountRef.current.clientHeight,
      0.1,
      1000
    );
    camera.position.z = 3;
    cameraRef.current = camera;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(
      mountRef.current.clientWidth,
      mountRef.current.clientHeight
    );
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    scene.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.8);
    directionalLight.position.set(5, 3, 5);
    scene.add(directionalLight);

    // Create globe with Earth texture
    const geometry = new THREE.SphereGeometry(1, 64, 64);

    // Load Earth texture
    const textureLoader = new THREE.TextureLoader();
    const earthTexture = textureLoader.load(
      "https://unpkg.com/three-globe/example/img/earth-blue-marble.jpg",
      () => {
        // Texture loaded successfully
        renderer.render(scene, camera);
      },
      undefined,
      (error) => {
        console.warn("Texture failed to load, using fallback color");
      }
    );

    const material = new THREE.MeshPhongMaterial({
      map: earthTexture,
      specular: 0x333333,
      shininess: 15,
      bumpScale: 0.005,
    });

    const globe = new THREE.Mesh(geometry, material);
    scene.add(globe);
    globeRef.current = globe;

    // Add country markers
    countries.forEach((country) => {
      const markerGeometry = new THREE.SphereGeometry(0.02, 8, 8);
      const markerMaterial = new THREE.MeshBasicMaterial({
        color: 0xff6b6b,
        transparent: true,
        opacity: 0.9,
      });
      const marker = new THREE.Mesh(markerGeometry, markerMaterial);

      // Convert lat/lng to 3D position
      const phi = (90 - country.lat) * (Math.PI / 180);
      const theta = (country.lng + 180) * (Math.PI / 180);
      const radius = 1.01;

      marker.position.x = -(radius * Math.sin(phi) * Math.cos(theta));
      marker.position.y = radius * Math.cos(phi);
      marker.position.z = radius * Math.sin(phi) * Math.sin(theta);

      marker.userData = { country: country.name };
      globe.add(marker);
    });

    // Add atmosphere glow
    const atmosphereGeometry = new THREE.SphereGeometry(1.15, 64, 64);
    const atmosphereMaterial = new THREE.MeshBasicMaterial({
      color: 0x4488ff,
      transparent: true,
      opacity: 0.1,
      side: THREE.BackSide,
    });
    const atmosphere = new THREE.Mesh(atmosphereGeometry, atmosphereMaterial);
    scene.add(atmosphere);

    // Mouse interaction
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (isDragging) {
        const deltaX = e.clientX - previousMousePosition.x;
        const deltaY = e.clientY - previousMousePosition.y;

        globe.rotation.y += deltaX * 0.005;
        globe.rotation.x += deltaY * 0.005;

        previousMousePosition = { x: e.clientX, y: e.clientY };
      }
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    const onClick = (e: MouseEvent) => {
      if (Math.abs(e.clientX - previousMousePosition.x) > 5) return;

      const rect = renderer.domElement.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(globe.children, true);

      if (intersects.length > 0) {
        const obj = intersects[0].object as THREE.Mesh;
        if (obj.userData.country) {
          setSelectedCountry(obj.userData.country);
          setCurrentPhotoIndex(0);
        }
      }
    };

    renderer.domElement.addEventListener("mousedown", onMouseDown);
    renderer.domElement.addEventListener("mousemove", onMouseMove);
    renderer.domElement.addEventListener("mouseup", onMouseUp);
    renderer.domElement.addEventListener("click", onClick);

    // Animation loop
    const animate = () => {
      requestAnimationFrame(animate);

      if (!isDragging) {
        globe.rotation.y += 0.001;
      }

      renderer.render(scene, camera);
    };
    animate();

    // Handle resize
    const handleResize = () => {
      if (!mountRef.current) return;
      camera.aspect =
        mountRef.current.clientWidth / mountRef.current.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(
        mountRef.current.clientWidth,
        mountRef.current.clientHeight
      );
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      renderer.domElement.removeEventListener("mousedown", onMouseDown);
      renderer.domElement.removeEventListener("mousemove", onMouseMove);
      renderer.domElement.removeEventListener("mouseup", onMouseUp);
      renderer.domElement.removeEventListener("click", onClick);
      if (mountRef.current) {
        mountRef.current.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        setCountryPhotos((prev) => ({
          ...prev,
          [selectedCountry!]: [
            ...(prev[selectedCountry!] || []),
            {
              url: event.target?.result as string,
              name: file.name,
              date: new Date().toISOString(),
            },
          ],
        }));
      };
      reader.readAsDataURL(file);
    });
  };

  const deletePhoto = (index: number) => {
    setCountryPhotos((prev) => ({
      ...prev,
      [selectedCountry!]: prev[selectedCountry!].filter((_, i) => i !== index),
    }));
    if (currentPhotoIndex >= countryPhotos[selectedCountry!]?.length - 1) {
      setCurrentPhotoIndex(Math.max(0, currentPhotoIndex - 1));
    }
  };

  const photos = countryPhotos[selectedCountry || ""] || [];

  return (
    <div className="app-container">
      {/* Globe Container */}
      <div ref={mountRef} className="globe-container" />

      {/* Stats */}
      <div className="stats-panel">
        <div className="stat-item">
          <Camera className="icon" />
          <span className="stat-value">
            {Object.keys(countryPhotos).length}
          </span>
          <span className="stat-label">Countries Visited</span>
        </div>
        <div className="stat-item">
          <Image className="icon" />
          <span className="stat-value">
            {Object.values(countryPhotos).reduce(
              (acc, photos) => acc + photos.length,
              0
            )}
          </span>
          <span className="stat-label">Total Photos</span>
        </div>
      </div>

      {/* Photo Album Modal */}
      {selectedCountry && (
        <div className="modal-overlay">
          <div className="modal-content">
            {/* Header */}
            <div className="modal-header">
              <h2 className="modal-title">{selectedCountry}</h2>
              <button
                onClick={() => setSelectedCountry(null)}
                className="close-button"
              >
                <X className="icon" />
              </button>
            </div>

            {/* Content */}
            <div className="modal-body">
              {photos.length === 0 ? (
                <div className="empty-state">
                  <Image className="empty-icon" />
                  <p className="empty-title">No photos yet</p>
                  <p className="empty-subtitle">
                    Upload your travel memories from {selectedCountry}
                  </p>
                </div>
              ) : (
                <div>
                  {/* Current Photo */}
                  <div className="photo-viewer">
                    <img
                      src={photos[currentPhotoIndex].url}
                      alt={photos[currentPhotoIndex].name}
                      className="current-photo"
                    />

                    {/* Navigation Arrows */}
                    {photos.length > 1 && (
                      <>
                        <button
                          onClick={() =>
                            setCurrentPhotoIndex(
                              (currentPhotoIndex - 1 + photos.length) %
                                photos.length
                            )
                          }
                          className="nav-button nav-left"
                        >
                          <ChevronLeft className="icon" />
                        </button>
                        <button
                          onClick={() =>
                            setCurrentPhotoIndex(
                              (currentPhotoIndex + 1) % photos.length
                            )
                          }
                          className="nav-button nav-right"
                        >
                          <ChevronRight className="icon" />
                        </button>
                      </>
                    )}

                    {/* Photo Counter */}
                    <div className="photo-counter">
                      {currentPhotoIndex + 1} / {photos.length}
                    </div>

                    {/* Delete Button */}
                    <button
                      onClick={() => deletePhoto(currentPhotoIndex)}
                      className="delete-button"
                    >
                      <X className="icon-small" />
                    </button>
                  </div>

                  {/* Thumbnail Strip */}
                  <div className="thumbnail-strip">
                    {photos.map((photo, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentPhotoIndex(index)}
                        className={`thumbnail ${
                          index === currentPhotoIndex ? "active" : ""
                        }`}
                      >
                        <img src={photo.url} alt={photo.name} />
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Upload Button */}
            <div className="modal-footer">
              <label className="upload-button">
                <Upload className="icon" />
                Upload Photos
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoUpload}
                  className="file-input"
                />
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
