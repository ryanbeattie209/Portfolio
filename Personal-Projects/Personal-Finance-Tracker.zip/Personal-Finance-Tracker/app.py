from flask import Flask, render_template, request, jsonify, send_from_directory, session, redirect, url_for
import sqlite3
from datetime import datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import io
import base64
import csv
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-this-in-production'

# Authentication decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Initialize the database
def initialize_database():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT,
            currency TEXT DEFAULT 'USD'
        )
    ''')
    
    # Transactions table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            account_id INTEGER,
            date TEXT,
            category TEXT,
            description TEXT,
            amount REAL,
            type TEXT,
            tags TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id),
            FOREIGN KEY (account_id) REFERENCES accounts(id)
        )
    ''')
    
    # Accounts table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            name TEXT,
            type TEXT,
            balance REAL DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # Budget limits table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS budget_limits (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            category TEXT,
            limit_amount REAL,
            period TEXT DEFAULT 'monthly',
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    # Savings goals table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS savings_goals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            name TEXT,
            target_amount REAL,
            current_amount REAL DEFAULT 0,
            deadline TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    conn.commit()
    conn.close()

initialize_database()

# Auth routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.json
        conn = sqlite3.connect('budget_tracker.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE username = ?', (data['username'],))
        user = cursor.fetchone()
        conn.close()
        
        if user and check_password_hash(user[2], data['password']):
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['currency'] = user[3]
            return jsonify({'success': True})
        return jsonify({'success': False, 'message': 'Invalid credentials'})
    
    return render_template('login.html')

@app.route('/register', methods=['POST'])
def register():
    data = request.json
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    try:
        hashed_password = generate_password_hash(data['password'])
        cursor.execute('INSERT INTO users (username, password, currency) VALUES (?, ?, ?)',
                      (data['username'], hashed_password, data.get('currency', 'USD')))
        conn.commit()
        user_id = cursor.lastrowid
        
        # Create default account
        cursor.execute('INSERT INTO accounts (user_id, name, type, balance) VALUES (?, ?, ?, ?)',
                      (user_id, 'Main Account', 'checking', 0))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    except sqlite3.IntegrityError:
        conn.close()
        return jsonify({'success': False, 'message': 'Username already exists'})

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/api/user-settings', methods=['GET', 'POST'])
@login_required
def user_settings():
    if request.method == 'POST':
        data = request.json
        conn = sqlite3.connect('budget_tracker.db')
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET currency = ? WHERE id = ?',
                      (data['currency'], session['user_id']))
        conn.commit()
        conn.close()
        session['currency'] = data['currency']
        return jsonify({'success': True})
    
    return jsonify({'currency': session.get('currency', 'USD')})

# Transaction routes
@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/api/transactions', methods=['GET'])
@login_required
def api_get_transactions():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT t.*, a.name as account_name 
        FROM transactions t
        LEFT JOIN accounts a ON t.account_id = a.id
        WHERE t.user_id = ?
        ORDER BY t.date DESC
    ''', (session['user_id'],))
    transactions = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'id': t[0],
        'account_id': t[2],
        'date': t[3],
        'category': t[4],
        'description': t[5],
        'amount': t[6],
        'type': t[7],
        'tags': t[8],
        'account_name': t[9]
    } for t in transactions])

@app.route('/api/transactions', methods=['POST'])
@login_required
def api_add_transaction():
    data = request.json
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO transactions (user_id, account_id, date, category, description, amount, type, tags)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (session['user_id'], data.get('account_id'), datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
          data['category'], data['description'], float(data['amount']), data['type'], data.get('tags', '')))
    
    # Update account balance
    if data.get('account_id'):
        amount = float(data['amount'])
        if data['type'] == 'income':
            cursor.execute('UPDATE accounts SET balance = balance + ? WHERE id = ?',
                          (amount, data['account_id']))
        else:
            cursor.execute('UPDATE accounts SET balance = balance - ? WHERE id = ?',
                          (amount, data['account_id']))
    
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/transactions/<int:transaction_id>', methods=['PUT', 'DELETE'])
@login_required
def api_modify_transaction(transaction_id):
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    if request.method == 'DELETE':
        # Get transaction details before deleting to update account balance
        cursor.execute('SELECT account_id, amount, type FROM transactions WHERE id = ? AND user_id = ?',
                      (transaction_id, session['user_id']))
        trans = cursor.fetchone()
        
        if trans and trans[0]:
            # Reverse the balance change
            if trans[2] == 'income':
                cursor.execute('UPDATE accounts SET balance = balance - ? WHERE id = ?',
                              (trans[1], trans[0]))
            else:
                cursor.execute('UPDATE accounts SET balance = balance + ? WHERE id = ?',
                              (trans[1], trans[0]))
        
        cursor.execute('DELETE FROM transactions WHERE id = ? AND user_id = ?',
                      (transaction_id, session['user_id']))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    
    elif request.method == 'PUT':
        data = request.json
        cursor.execute('''
            UPDATE transactions 
            SET category = ?, description = ?, amount = ?, tags = ?
            WHERE id = ? AND user_id = ?
        ''', (data['category'], data['description'], float(data['amount']),
              data.get('tags', ''), transaction_id, session['user_id']))
        conn.commit()
        conn.close()
        return jsonify({'success': True})

# Account routes
@app.route('/api/accounts', methods=['GET', 'POST'])
@login_required
def api_accounts():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    if request.method == 'POST':
        data = request.json
        cursor.execute('INSERT INTO accounts (user_id, name, type, balance) VALUES (?, ?, ?, ?)',
                      (session['user_id'], data['name'], data['type'], float(data.get('balance', 0))))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    
    cursor.execute('SELECT * FROM accounts WHERE user_id = ?', (session['user_id'],))
    accounts = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'id': a[0],
        'name': a[2],
        'type': a[3],
        'balance': a[4]
    } for a in accounts])

# Budget limits routes
@app.route('/api/budget-limits', methods=['GET', 'POST'])
@login_required
def api_budget_limits():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    if request.method == 'POST':
        data = request.json
        cursor.execute('''
            INSERT OR REPLACE INTO budget_limits (user_id, category, limit_amount, period)
            VALUES (?, ?, ?, ?)
        ''', (session['user_id'], data['category'], float(data['limit_amount']), data.get('period', 'monthly')))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    
    cursor.execute('SELECT * FROM budget_limits WHERE user_id = ?', (session['user_id'],))
    limits = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'id': l[0],
        'category': l[2],
        'limit_amount': l[3],
        'period': l[4]
    } for l in limits])

@app.route('/api/budget-status', methods=['GET'])
@login_required
def api_budget_status():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    # Get current month spending per category
    cursor.execute('''
        SELECT category, SUM(amount) as total
        FROM transactions
        WHERE user_id = ? AND type = 'expense' 
        AND strftime('%Y-%m', date) = strftime('%Y-%m', 'now')
        GROUP BY category
    ''', (session['user_id'],))
    spending = dict(cursor.fetchall())
    
    # Get budget limits
    cursor.execute('SELECT category, limit_amount FROM budget_limits WHERE user_id = ?',
                  (session['user_id'],))
    limits = cursor.fetchall()
    conn.close()
    
    status = []
    for category, limit in limits:
        spent = spending.get(category, 0)
        percentage = (spent / limit * 100) if limit > 0 else 0
        status.append({
            'category': category,
            'limit': limit,
            'spent': spent,
            'remaining': limit - spent,
            'percentage': percentage
        })
    
    return jsonify(status)

# Savings goals routes
@app.route('/api/savings-goals', methods=['GET', 'POST'])
@login_required
def api_savings_goals():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    
    if request.method == 'POST':
        data = request.json
        cursor.execute('''
            INSERT INTO savings_goals (user_id, name, target_amount, current_amount, deadline)
            VALUES (?, ?, ?, ?, ?)
        ''', (session['user_id'], data['name'], float(data['target_amount']),
              float(data.get('current_amount', 0)), data.get('deadline', '')))
        conn.commit()
        conn.close()
        return jsonify({'success': True})
    
    cursor.execute('SELECT * FROM savings_goals WHERE user_id = ?', (session['user_id'],))
    goals = cursor.fetchall()
    conn.close()
    
    return jsonify([{
        'id': g[0],
        'name': g[2],
        'target_amount': g[3],
        'current_amount': g[4],
        'deadline': g[5],
        'percentage': (g[4] / g[3] * 100) if g[3] > 0 else 0
    } for g in goals])

@app.route('/api/savings-goals/<int:goal_id>', methods=['PUT'])
@login_required
def api_update_goal(goal_id):
    data = request.json
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    cursor.execute('UPDATE savings_goals SET current_amount = ? WHERE id = ? AND user_id = ?',
                  (float(data['current_amount']), goal_id, session['user_id']))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

# Export routes
@app.route('/api/export-csv')
@login_required
def export_csv():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT date, category, description, amount, type, tags
        FROM transactions WHERE user_id = ?
        ORDER BY date DESC
    ''', (session['user_id'],))
    transactions = cursor.fetchall()
    conn.close()
    
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Date', 'Category', 'Description', 'Amount', 'Type', 'Tags'])
    writer.writerows(transactions)
    
    return jsonify({'csv': output.getvalue()})

# Other routes
@app.route('/api/categorized-spending', methods=['GET'])
@login_required
def api_categorized_spending():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT category, SUM(amount) FROM transactions
        WHERE type = 'expense' AND user_id = ?
        GROUP BY category
    ''', (session['user_id'],))
    spending = cursor.fetchall()
    conn.close()
    return jsonify([{'category': s[0], 'total': s[1]} for s in spending])

@app.route('/api/spending-chart', methods=['GET'])
@login_required
def api_spending_chart():
    conn = sqlite3.connect('budget_tracker.db')
    cursor = conn.cursor()
    cursor.execute('''
        SELECT category, SUM(amount) FROM transactions
        WHERE type = 'expense' AND user_id = ?
        GROUP BY category
    ''', (session['user_id'],))
    spending = cursor.fetchall()
    conn.close()
    
    if not spending:
        return jsonify({'chart': None})
    
    categories = [row[0] for row in spending]
    amounts = [row[1] for row in spending]
    
    plt.figure(figsize=(8, 6))
    plt.pie(amounts, labels=categories, autopct='%1.1f%%', startangle=140)
    plt.title("Spending by Category")
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png', bbox_inches='tight')
    buf.seek(0)
    plt.close()
    
    image_base64 = base64.b64encode(buf.read()).decode('utf-8')
    return jsonify({'chart': image_base64})

@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

if __name__ == '__main__':
    app.run(debug=True, port=5000)