// Game.js

// Import React hooks for state management, references, and side effects
import React, { useState, useRef, useEffect } from "react";

// Import Three.js React components for 3D rendering
import { Canvas, useFrame, useThree } from "@react-three/fiber";

// Import XR (AR/VR) support for immersive experiences
import { XR, createXRStore } from "@react-three/xr";

// Import helper components from drei library
import { OrbitControls, Html } from "@react-three/drei";

// Import Three.js library for 3D math and utilities
import * as THREE from "three";

// ========================================
// GAME CONFIGURATION CONSTANTS
// ========================================

// Total game duration in seconds
const GAME_DURATION = 30;

// Average human eye height in meters (used for camera positioning)
const AVERAGE_EYE_HEIGHT = 1.6;

// Minimum height the target can appear at (prevents target from being too low)
const MIN_HEIGHT = 0.9;

// Maximum height the target can appear at (prevents target from being too high)
const MAX_HEIGHT = 2.1;

// Distance from camera to target in meters
const TARGET_DISTANCE = 2.5;

// Configuration for the concentric rings that make up the target
// Each ring has a radius, color, and z-offset (for layering)
const RING_CONFIG = [
  { radius: 0.1, color: "red", z: 0 }, // Center bullseye (red)
  { radius: 0.2, color: "black", z: -0.01 }, // Second ring (black)
  { radius: 0.3, color: "white", z: -0.02 }, // Third ring (white)
  { radius: 0.4, color: "black", z: -0.03 }, // Fourth ring (black)
  { radius: 0.5, color: "white", z: -0.04 }, // Fifth ring (white)
  { radius: 0.6, color: "transparent", z: -0.05 }, // Outer ring (transparent, used for hit detection)
];

// Create an XR store for managing AR/VR sessions
const store = createXRStore();

// ========================================
// EXPLOSION EFFECT COMPONENT
// ========================================

/**
 * ExplosionEffect Component
 *
 * Creates an animated explosion effect with expanding concentric spheres
 * that fade out over time.
 *
 * @param {Array} position - [x, y, z] position where explosion should appear
 * @param {boolean} trigger - When true, plays the explosion animation
 * @param {Function} onEnd - Callback function called when animation completes
 */
function ExplosionEffect({ position, trigger, onEnd }) {
  // Reference to the group containing all explosion spheres
  const groupRef = useRef();

  // Track elapsed time for the animation
  const clockRef = useRef(0);

  // Animation loop that runs every frame
  useFrame((_, delta) => {
    // Only animate if trigger is true and the group exists
    if (trigger && groupRef.current) {
      // Increment the animation clock by the time since last frame
      clockRef.current += delta;

      // Scale up the entire explosion group (makes it expand)
      groupRef.current.scale.setScalar(1 + clockRef.current * 10);

      // Fade out each sphere in the explosion
      groupRef.current.children.forEach((child) => {
        if (child.material) {
          // Opacity decreases from 1 to 0 over time
          child.material.opacity = Math.max(0, 1 - clockRef.current * 2);
        }
      });

      // After 1 second, end the animation and reset
      if (clockRef.current > 1) {
        onEnd();
        clockRef.current = 0;
      }
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Outer orange sphere */}
      <mesh>
        <sphereGeometry args={[1, 64, 64]} />
        <meshBasicMaterial color="orange" transparent opacity={1} />
      </mesh>

      {/* Middle yellow sphere */}
      <mesh>
        <sphereGeometry args={[0.8, 64, 64]} />
        <meshBasicMaterial color="yellow" transparent opacity={1} />
      </mesh>

      {/* Inner red sphere */}
      <mesh>
        <sphereGeometry args={[0.6, 64, 64]} />
        <meshBasicMaterial color="red" transparent opacity={1} />
      </mesh>
    </group>
  );
}

// ========================================
// TARGET COMPONENT
// ========================================

/**
 * Target Component
 *
 * Creates an interactive target (bullseye) that follows the camera's view
 * and responds to clicks by triggering explosions and moving to new positions.
 *
 * @param {Function} setExplosionTrigger - Sets whether explosion animation should play
 * @param {Function} setExplosionPosition - Sets position where explosion appears
 * @param {Function} onHit - Callback when target is hit (increments score)
 */
function Target({ setExplosionTrigger, setExplosionPosition, onHit }) {
  // Reference to the target group for positioning and rotation
  const targetRef = useRef();

  // Access to the Three.js camera
  const { camera } = useThree();

  // Track whether target is currently moving to a new position
  const [moving, setMoving] = useState(false);

  // The destination position when target is moving
  const [targetMovingPosition, setTargetMovingPosition] = useState([0, 0, 0]);

  /**
   * Plays a random glass breaking sound effect
   * Sound starts at 1.5 seconds to skip intro
   */
  const playRandomSound = () => {
    const sounds = [
      "/sounds/Glass Smashes Epidemic Sound.mp3",
      "/sounds/Bottle Hit Break With Hammer 01 Epidemic Sound.mp3",
      "/sounds/Bottle Hit Break With Hammer 02 Epidemic Sound.mp3",
      "/sounds/Bottle Smash On Other Glass Bottles And Jars Epidemic Sound.mp3",
    ];

    // Select a random sound from the array
    const randomIndex = Math.floor(Math.random() * sounds.length);
    const audio = new Audio(sounds[randomIndex]);
    audio.currentTime = 1.5111; // Skip to the impact sound
    audio.play();
  };

  /**
   * Generates a new position for the target
   *
   * @param {boolean} isHit - If true, target moves far away; if false, stays near camera
   * @returns {Array} [x, y, z] position coordinates
   */
  const generateNewPosition = (isHit = false) => {
    // Get the camera's current position in world space
    const worldCameraPosition = new THREE.Vector3();
    camera.getWorldPosition(worldCameraPosition);

    // Set Y position based on camera height, clamped to min/max values
    let newY = worldCameraPosition.y;
    newY = Math.max(MIN_HEIGHT, Math.min(newY, MAX_HEIGHT));

    // Get the direction the camera is facing
    const direction = new THREE.Vector3();
    camera.getWorldDirection(direction);
    direction.multiplyScalar(TARGET_DISTANCE);

    if (isHit) {
      // When hit, move target far to the side and forward
      const offsetX =
        Math.random() < 0.5 ? Math.random() * 10 + 5 : -Math.random() * 10 - 5;
      const offsetZ = Math.random() * 5 + 5;
      return [
        worldCameraPosition.x + offsetX,
        newY,
        worldCameraPosition.z + direction.z + offsetZ,
      ];
    } else {
      // Normal positioning: slight random offset near camera's view
      return [
        worldCameraPosition.x + (Math.random() * 2 - 1),
        newY,
        worldCameraPosition.z + direction.z,
      ];
    }
  };

  // Animation loop - runs every frame
  useFrame(() => {
    if (targetRef.current) {
      // Update target position to follow camera
      const worldCameraPosition = new THREE.Vector3();
      camera.getWorldPosition(worldCameraPosition);

      // Calculate target height based on camera height
      let targetY = worldCameraPosition.y;
      targetY = Math.max(MIN_HEIGHT, Math.min(targetY, MAX_HEIGHT));

      // Position target in front of camera at TARGET_DISTANCE
      const direction = new THREE.Vector3();
      camera.getWorldDirection(direction);
      direction.multiplyScalar(TARGET_DISTANCE);

      targetRef.current.position.set(
        worldCameraPosition.x + direction.x,
        targetY,
        worldCameraPosition.z + direction.z
      );

      // Make target face the camera
      targetRef.current.lookAt(worldCameraPosition);
    }

    // Smoothly move target to new position after being hit
    if (moving) {
      const currentPos = targetRef.current.position;
      const targetPos = new THREE.Vector3(...targetMovingPosition);

      // Lerp (linear interpolation) creates smooth movement
      currentPos.lerp(targetPos, 0.1);
      targetRef.current.position.copy(currentPos);

      // Stop moving when close enough to target position
      if (currentPos.distanceTo(targetPos) < 0.1) {
        setMoving(false);
      }
    }
  });

  /**
   * Handles when the target is clicked/hit
   * Triggers explosion, plays sound, updates score, and moves target
   */
  const handleTargetClick = () => {
    // Trigger explosion effect at current target position
    setExplosionTrigger(true);
    setExplosionPosition(targetRef.current.position.toArray());

    // Play random breaking sound
    playRandomSound();

    // Increment the score
    onHit();

    // After 1 second delay, move target to new position
    setTimeout(() => {
      const newPos = generateNewPosition(true);
      setTargetMovingPosition(newPos);
      setMoving(true);
      setExplosionTrigger(false);
    }, 1000);
  };

  return (
    <group ref={targetRef} onClick={handleTargetClick}>
      {/* Render each concentric ring of the target */}
      {RING_CONFIG.map((ring, index) => (
        <mesh key={index} position={[0, 0, ring.z]}>
          <circleGeometry args={[ring.radius, 64]} />
          <meshBasicMaterial
            color={ring.color}
            transparent={ring.color === "transparent"}
            opacity={ring.color === "transparent" ? 0 : 1}
          />
        </mesh>
      ))}
    </group>
  );
}

// ========================================
// MAIN GAME COMPONENT
// ========================================

/**
 * Game Component
 *
 * Main game controller that manages:
 * - Game state (started, over, score, time)
 * - UI buttons (Enter XR, Start Game)
 * - 3D scene with target, explosions, and lighting
 * - Timer countdown
 */
export default function Game() {
  // Game timer (counts down from GAME_DURATION)
  const [timeRemaining, setTimeRemaining] = useState(GAME_DURATION);

  // Target's current position [x, y, z]
  const [targetPosition, setTargetPosition] = useState([
    0,
    AVERAGE_EYE_HEIGHT,
    -TARGET_DISTANCE,
  ]);

  // Controls whether explosion animation is playing
  const [explosionTrigger, setExplosionTrigger] = useState(false);

  // Position where explosion should appear
  const [explosionPosition, setExplosionPosition] = useState([
    0,
    0,
    -TARGET_DISTANCE,
  ]);

  // Player's current score (number of targets hit)
  const [score, setScore] = useState(0);

  // Whether the game has ended (time ran out)
  const [gameOver, setGameOver] = useState(false);

  // Whether the game has been started by the player
  const [gameStarted, setGameStarted] = useState(false);

  /**
   * Effect hook for managing the countdown timer
   * Decrements time every second when game is active
   * Sets gameOver to true when time reaches 0
   */
  useEffect(() => {
    if (timeRemaining > 0 && gameStarted && !gameOver) {
      const timer = setInterval(() => {
        setTimeRemaining((prevTime) => prevTime - 1);
      }, 1000);

      // Cleanup: clear interval when component unmounts or dependencies change
      return () => clearInterval(timer);
    } else if (timeRemaining === 0) {
      setGameOver(true);
    }
  }, [timeRemaining, gameStarted, gameOver]);

  /**
   * Increments the score when a target is hit
   */
  const handleTargetHit = () => {
    setScore((prevScore) => prevScore + 1);
  };

  /**
   * Starts the game when player clicks "Start Game" button
   */
  const startGame = () => {
    setGameStarted(true);
  };

  return (
    <>
      {/* Button to enter AR/VR mode */}
      <button
        onClick={() => store.enterAR()}
        style={{
          position: "absolute",
          top: "20px",
          left: "50%",
          transform: "translateX(-50%)",
          padding: "10px 20px",
          fontSize: "18px",
          cursor: "pointer",
          zIndex: 1000,
        }}
      >
        Enter XR
      </button>

      {/* "Start Game" button - only shown before game starts */}
      {!gameStarted && !gameOver && (
        <button
          onClick={startGame}
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            transform: "translate(-50%, -50%)",
            padding: "10px 20px",
            fontSize: "18px",
            cursor: "pointer",
            zIndex: 1000,
          }}
        >
          Start Game
        </button>
      )}

      {/* 3D Canvas - renders the entire 3D scene */}
      <Canvas camera={{ position: [0, AVERAGE_EYE_HEIGHT, 3] }}>
        {/* XR wrapper enables AR/VR functionality */}
        <XR store={store}>
          {/* Ambient light provides general illumination */}
          <ambientLight intensity={0.5} />

          {/* Point light adds directional lighting */}
          <pointLight position={[-10, -10, -10]} intensity={1} />

          {/* Render target only if game is not over */}
          {!gameOver && (
            <Target
              setExplosionTrigger={setExplosionTrigger}
              setExplosionPosition={setExplosionPosition}
              onHit={handleTargetHit}
            />
          )}

          {/* Render explosion effect when triggered */}
          {explosionTrigger && (
            <ExplosionEffect
              position={explosionPosition}
              trigger={explosionTrigger}
              onEnd={() => setExplosionTrigger(false)}
            />
          )}

          {/* Camera controls for mouse/touch interaction */}
          <OrbitControls />

          {/* HTML overlay for displaying game UI in 3D space */}
          <Html position={[0, 0, 0]} distanceFactor={10} transform>
            {/* Timer display - turns red when 5 seconds or less remain */}
            <div
              style={{
                position: "absolute",
                top: "-350px",
                left: "50%",
                transform: "translateX(-50%)",
                color: timeRemaining <= 5 ? "red" : "white",
                fontSize: "20px",
                fontWeight: "bold",
                zIndex: 1000,
              }}
            >
              Time Left: {timeRemaining}s
            </div>

            {/* Game over message with final score */}
            {gameOver && (
              <div
                style={{
                  position: "absolute",
                  top: "0",
                  left: "50%",
                  transform: "translateX(-50%)",
                  color: "yellow",
                  fontSize: "30px",
                  fontWeight: "bold",
                  zIndex: 1000,
                }}
              >
                Game Over! Final Score: {score}
              </div>
            )}
          </Html>
        </XR>
      </Canvas>
    </>
  );
}
