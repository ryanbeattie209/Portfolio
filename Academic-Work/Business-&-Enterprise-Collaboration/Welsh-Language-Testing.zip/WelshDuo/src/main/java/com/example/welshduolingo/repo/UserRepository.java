package com.example.welshduolingo.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.welshduolingo.model.User;


@Repository
public interface UserRepository extends CrudRepository<User, String> {

	int countByUsername(String string);

	void deleteByUsername(String username);

	User findByUsername(String username);


	
}
