package com.example.welshduolingo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

@Entity
public class Noun {

	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	
	@NotNull
	public String englishWord;
	

	public String welshWord;
	

	public String welshWordGender;

	public String getenglishWord() {
		return englishWord;
	}

	public void setenglishWord(String englishWord) {
		this.englishWord = englishWord;
	}

	public String getwelshWord() {
		return welshWord;
	}

	public void setwelshWord(String welshWord) {
		this.welshWord = welshWord;
	}

	public String getwelshWordGender() {
		return welshWordGender;
	}

	public void setwelshWordGender(String welshWordGender) {
		this.welshWordGender = welshWordGender;
	}
	
	public String toStringEnglish() {
		return englishWord;
	}
	
}
