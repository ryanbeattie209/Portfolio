package com.example.welshduolingo.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.welshduolingo.model.Permission;


@Repository
public interface PermissionRepository extends CrudRepository<Permission, Integer> {

	int countByRoleName(String string);

	Permission findByRoleName(String string);

}
