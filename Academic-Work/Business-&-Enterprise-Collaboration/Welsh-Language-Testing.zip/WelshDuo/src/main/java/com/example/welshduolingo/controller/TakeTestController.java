package com.example.welshduolingo.controller;


import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.welshduolingo.model.Noun;
import com.example.welshduolingo.model.Question;
import com.example.welshduolingo.model.Tests;
import com.example.welshduolingo.model.User;
import com.example.welshduolingo.repo.NounRepository;
import com.example.welshduolingo.repo.QuestionRepository;
import com.example.welshduolingo.repo.TestRepository;
import com.example.welshduolingo.repo.UserRepository;



@Controller
public class TakeTestController{
	
	@Autowired
	private NounRepository nounRepo;
	
	@Autowired
	private TestRepository testRepo;
	
	@Autowired
	private QuestionRepository queRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	private int testId;
	
	List<String> questionAnswersList = new ArrayList<String>();
	// https://stackoverflow.com/questions/48358478/how-can-i-display-the-current-logged-in-user-with-spring-boot-thymeleaf
	
	
	
	@GetMapping("/taketest")
	public String takeTest(Model model) {
		Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
		String username = loggedInUser.getName();
		Random rand = new Random();
		Tests t = new Tests();
		t.setUsernameTaken(username);
		testRepo.save(t);
		
		testId= t.getId();
		
		List<String> questions = new ArrayList<String>();
		List<String> englishUsed = new ArrayList<String>();
		List<String> welshUsed = new ArrayList<String>();
		List<String> welshGen = new ArrayList<String>();
		
		for (int i = 0; i < 20;) {
			int id = rand.nextInt(1,40);
			int lang = rand.nextInt(0,2);
			int type = rand.nextInt(0,2);
			
			Question q = new Question();
			q.setTest(t);
			String ques;
			
			

			
			if(lang == 1) {
				Noun n = nounRepo.getEnglishWordById(id);
				String wordused = n.getenglishWord();
				if(englishUsed.contains(wordused)) {
					continue;
				}else {
					q.setQuestion(n.getenglishWord());
					q.setQuestionAnswer(n.getwelshWord());
					questionAnswersList.add(n.getwelshWord());
					ques = "What is " + n.getenglishWord() + " In Welsh";
					englishUsed.add(n.getenglishWord());
					System.out.println(englishUsed);
					System.out.println(wordused);
					i++;
				}
					
				
				
			
			}else {
				if(type == 1) {
					Noun p = nounRepo.getWelshWordById(id);
					String welshWord = p.getwelshWord();
					if(welshUsed.contains(welshWord)) {
						continue;
					}else {
						ques = "What is " + p.getwelshWord() + " In English";
						q.setQuestion(p.getwelshWord());
						q.setQuestionAnswer(p.getenglishWord());
						questionAnswersList.add(p.getenglishWord());
						welshUsed.add(p.getwelshWord());
						i++;
					}
					

				}else {
					Noun p = nounRepo.getWelshWordById(id);
					String welshUsedTwo = p.getwelshWord();
					if(welshGen.contains(welshUsedTwo)) {
						continue;
					}else {
						ques = "What is " + p.getwelshWord() + "'s Gender";
						q.setQuestion(p.getwelshWord());
						q.setQuestionAnswer(p.getwelshWordGender());
						questionAnswersList.add(p.getwelshWordGender());
						i++;
					}

				}
				
			}
			questions.add(ques);
			queRepo.save(q);
			
		}
		
		model.addAttribute("questions", questions);
		return "/taketest";
	}
	
	
	
	@GetMapping("/submittest")
	public String submitTest(@RequestParam("userAnswers") String[] userAnswers, Model model) {
		Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
		String username = loggedInUser.getName();
		User u = userRepo.findByUsername(username);
		String[] questionAnswersArray = questionAnswersList.toArray(String[]::new);
		int UserScore = 0;
		Tests t = testRepo.findById(testId);
		for (int i = 0; i < 20; i++) {
			if (questionAnswersArray[i].equals(userAnswers[i])) {
				UserScore ++;
			}else {
				;
			}
			System.out.println(questionAnswersArray[i]);
			System.out.println(userAnswers[i]);
			
		}
		t.setScore(UserScore);
		u.setTotalScore(u.getTotalScore() + UserScore);
		testRepo.save(t);
		model.addAttribute("score", UserScore);
		System.out.println(UserScore + " Score");
		questionAnswersList.clear();
		return "showscore";
	}
	
	@GetMapping("/viewtest")
	public String viewTest(Model model) {
		Authentication loggedInUser = SecurityContextHolder.getContext().getAuthentication();
		String username = loggedInUser.getName();
		List<Tests> tests = testRepo.findByUsernameTaken(username);
		model.addAttribute("tests", tests);
		return "/viewtest";
	}
	
	
	@GetMapping("/leaderboard")
	public String viewLeaderboard(Model model) {
		List<User> users = (List<User>) userRepo.findAll();
		model.addAttribute("users", users);
		return "/leaderboard";
	}
	
}




