package com.example.welshduolingo.security;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.welshduolingo.model.Noun;
import com.example.welshduolingo.model.Permission;
import com.example.welshduolingo.repo.NounRepository;

import jakarta.annotation.PostConstruct;
import jakarta.transaction.Transactional;

@Component
public class FirstLoadNounConfigurer {

	@Autowired
	private NounRepository nounRepo;
	
	
	@PostConstruct
	public void setup() {
		
		
		String[] englishWords = {"House","Cat","Chair","Dog","Book","Cottage","Window","Bridge","Milk","Car","Phone","Farm","Sea","Moon","Kitchen","Fox","Line","Rose","Finger","Clock","Child","Forest","Flower","Bucket","Valleys","King","Daughter","Man","Woman","Wolf","Place","Wine","River","Clouds","Picture","Beech","Leek","Fox","Cheese","Turtle"};
		String[] welshWords = {"Ty","Cath","Cadair","Cwn","Llyfr","Bwthyn","Ffenestr","Pont","Llefrith","Car","Ffon","Fferm","Mor","Lleuad","Cegin","Llwynog","Llinell","Rhosyn","Bys","Cloc","Plentyn","Fforest","Blodyn","Bwced","Cymoedd","Brenin","Merch","Gwr","Menyw","Blaidd","Lleu","Gwin","Afon","Cymylau","Llun","Traeth","Cennin","Cadno","Caws","Crwban"};
		String[] welshWordGenders = {"m","f","f","m","m","n","f","m","f","m","m","f","m","f","f","m","f","f","m","m","m","f","f","m","m","m","f","m","f","m","m","f","f","m","m","m","m","m","m","f"};
		
		if (nounRepo.count() < 1)
			for (int i = 0; i < 40; i++) {
	            Noun n = new Noun();
	            n.setenglishWord(englishWords[i]);
	            n.setwelshWord(welshWords[i]);
	            n.setwelshWordGender(welshWordGenders[i]);
	            nounRepo.save(n);
	        };
		
        
		
	}
	
}
