package com.example.welshduolingo.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.welshduolingo.model.Noun;
import com.example.welshduolingo.model.User;

@Repository
public interface NounRepository extends CrudRepository<Noun, Integer> {

	int countByEnglishWord(String string);

	Noun findByEnglishWord(String EnglishWord);

	void deleteByEnglishWord(String EnglishWord);

	Noun getEnglishWordById(int id);

	Noun getWelshWordById(int id);



}
