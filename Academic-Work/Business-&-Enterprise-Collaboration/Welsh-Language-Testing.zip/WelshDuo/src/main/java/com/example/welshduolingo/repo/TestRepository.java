package com.example.welshduolingo.repo;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.welshduolingo.model.Tests;


@Repository
public interface TestRepository extends CrudRepository<Tests, Integer> {

	Tests findById(int id);

	List<Tests> findByUsernameTaken(String username);

}
