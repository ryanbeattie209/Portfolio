package com.example.welshduolingo.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Question {

	public Question(){
		
	}
	
	@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	
	private List<Tests> tests;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	

	public String question;
	
	public String questionAnswer;
	
	@ManyToOne
    private Tests test;
	
	public List<Tests> getTests() {
		return tests;
	}


	
	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getQuestionAnswer() {
		return questionAnswer;
	}

	public void setQuestionAnswer(String questionAnswer) {
		this.questionAnswer = questionAnswer;
	}



	public void setTest(Tests test) {
		this.test = test;
		
	}
	
}
