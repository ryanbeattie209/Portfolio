package com.example.welshduolingo.controller;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.welshduolingo.model.Noun;
import com.example.welshduolingo.model.Permission;
import com.example.welshduolingo.model.Tests;
import com.example.welshduolingo.model.User;
import com.example.welshduolingo.repo.NounRepository;
import com.example.welshduolingo.repo.PermissionRepository;
import com.example.welshduolingo.repo.TestRepository;
import com.example.welshduolingo.repo.UserRepository;

import jakarta.transaction.Transactional;

@Controller
public class AdminViewController {

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private TestRepository testRepo;

	@Autowired
	private PermissionRepository permRepo;
	
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private NounRepository nounRepo;
	
	@GetMapping("/adminview")
	public String loginForm(Model model) {
		List<User> users = (List<User>) userRepo.findAll();
		model.addAttribute("users", users);
		
		List<Noun> nouns = (List<Noun>) nounRepo.findAll();
		model.addAttribute("nouns", nouns);
		return "/adminview";
	}
	
	
	@GetMapping("/adduser")
	@Secured("ROLE_ADMIN")
	public String addUser(@RequestParam("username") String username,@RequestParam("password") String password,@RequestParam("role") String role) {
		User u = new User();
		u.setUsername(username);
		u.setPassword(passwordEncoder.encode(password));
		List<Permission> p = new LinkedList<Permission>();
		p.add(permRepo.findByRoleName(role));
		u.setPermissions(p);
		userRepo.save(u);
		return "redirect:/adminview";
	}
	
	
	
	@GetMapping("/deleteuser")
	@Transactional  // Without it it gives error that you can't complete without a transaction
	public String deleteUser(@RequestParam("username") String username) {
		User u = userRepo.findByUsername(username);
		u.getPermissions().clear();
		userRepo.deleteByUsername(username);
		return "redirect:/adminview";
	}
	
	@GetMapping("/edituserpass")
	public String editUserPass(@RequestParam("username") String username, @RequestParam("password") String password) {
		User u = userRepo.findByUsername(username);
		u.setPassword(passwordEncoder.encode(password));
		userRepo.save(u);
		return "redirect:/adminview";
	}

	@GetMapping("/edituserrole")
	public String editUserRole(@RequestParam("username") String username, @RequestParam("role") String role) {
		User u = userRepo.findByUsername(username);
		List<Permission> p = new LinkedList<Permission>();
		p.add(permRepo.findByRoleName(role));
		u.setPermissions(p);
		userRepo.save(u);
		return "redirect:/adminview";
	}
	
	@GetMapping("/newnoun")
	public String addNoun(@RequestParam("nounEng") String nounEng, @RequestParam("nounWel") String nounWel, @RequestParam("nounGen") String nounGen) {
		Noun n = new Noun();
		n.setenglishWord(nounEng);
		n.setwelshWord(nounWel);
		n.setwelshWordGender(nounGen);
		nounRepo.save(n);
		return "redirect:/adminview";
	}
	
	@GetMapping("/deletenoun")
	@Transactional  // Without it it gives error that you can't complete without a transaction
	public String deleteNoun(@RequestParam("nouns") String nouns) {
		Noun n = nounRepo.findByEnglishWord(nouns);
		nounRepo.deleteByEnglishWord(nouns);
		return "redirect:/adminview";
	}
	
	@GetMapping("/editnoun")
	public String editNoun(@RequestParam("nounToChangeEng") String nounToChangeEng, @RequestParam("newEngNoun") String newEngNoun, @RequestParam("newWelNoun") String newWelNoun, @RequestParam("newNounGen") String newNounGen) {
		Noun n = nounRepo.findByEnglishWord(nounToChangeEng);
		n.setwelshWord(newWelNoun);
		n.setenglishWord(newEngNoun);
		n.setwelshWordGender(newNounGen);
		nounRepo.save(n);
		return "redirect:/adminview";
	}
	

	
	
}