package com.example.welshduolingo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

@Entity
public class Tests {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	
	@NotNull
	public String usernameTaken;

	
	public int Score;


	public int getScore() {
		return Score;
	}


	public void setScore(int score) {
		Score = score;
	}


	public String getUsernameTaken() {
		return usernameTaken;
	}


	public void setUsernameTaken(String usernameTaken) {
		this.usernameTaken = usernameTaken;
	}


	public int getId() {
		return id;
	}



	
	
}