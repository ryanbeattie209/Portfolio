package com.example.welshduolingo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;




@SpringBootApplication
public class WelshDuoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WelshDuoApplication.class, args);
	}

}
