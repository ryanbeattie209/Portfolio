package com.example.rrp.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.rrp.model.Session;
import java.util.List;
import java.util.Optional;

@Repository
public interface SessionRepository extends CrudRepository<Session, Integer> {

	@Query("SELECT s FROM Session s WHERE s.dynamicCode = :dynamicCode AND s.active = true")
	Optional<Session> findActiveSessionByDynamicCode(String dynamicCode);

	@Query("SELECT s FROM Session s WHERE s.active = true ORDER BY s.startTime DESC")
	List<Session> findActiveSessionsOrderedByStartTime();

	Optional<Session> findFirstByActiveTrueOrderByStartTimeDesc();

}