package com.example.rrp.controller;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.rrp.model.Session;
import com.example.rrp.repo.SessionRepository;
import com.example.rrp.service.SessionService;
import com.example.rrp.service.UserService;

@Controller
public class LecturerController {

	private final SessionService sessionService;
	private final SessionRepository sessionRepository;
	private final UserService userService;

	@Autowired
	public LecturerController(SessionService sessionService, SessionRepository sessionRepository,
			UserService userService) {
		this.sessionService = sessionService;
		this.sessionRepository = sessionRepository;
		this.userService = userService;
	}

	
	/**
	 * @param moduleCode
	 * @return
	 * Creates Session by taking in lecturer inputed code
	 */
	@PostMapping("/lecturer/createSession")
	
	public String createSession(@RequestParam String moduleCode) {
		sessionService.createSession(moduleCode, LocalDateTime.now());
		return "redirect:/lecturer/createSession";
	}

	/**
	 * @param model
	 * @return
	 * Checks for existing sessions and shows results
	 */
	@GetMapping("/lecturer/existingSessions")
	
	public String existingSessionsPage(Model model) {
		model.addAttribute("sessionData", sessionService.getActiveSessionsOrdered());
		return "existingSessions";
	}

	/**
	 * @param sessionId
	 * @return
	 * Lecturer can end sessions 
	 */
	@PostMapping("/lecturer/endSession")
	
	public String endSession(@RequestParam int sessionId) {
		sessionService.endSession(sessionId);
		return "redirect:/lecturer/existingSessions";
	}

	/**
	 * @param username
	 * @param password
	 * @param role
	 * @param libraryCard
	 * @param model
	 * @return
	 * Lecturer can add user to the database by entering there username password role library card
	 */
	@PostMapping("/lecturer/addUser")
	
	public String addUser(@RequestParam String username, @RequestParam String password, @RequestParam String role,
			@RequestParam String libraryCard, Model model) {
		List<String> roles = Arrays.asList(role.split(","));
		userService.createUser(username, password, roles, libraryCard);
		model.addAttribute("message", "User added successfully!");
		return "redirect:/lecturer/addUser";
	}

	/**
	 * @param sessionId
	 * @param model
	 * @return
	 * Creates a session random display code used for the user to log into session with
	 */
	@GetMapping("/lecturer/session/{sessionId}")
	
	public String showSessionCode(@PathVariable int sessionId, Model model) {
		Session session = sessionRepository.findById(sessionId).orElse(null);
		if (session != null) {
			model.addAttribute("dynamicCode", session.getDynamicCode());
			return "sessionCodeDisplay";
		}
		return "redirect:/lecturer/existingSessions";
	}

	@GetMapping("/lecturer/sessionCode/{sessionId}")
	@ResponseBody
	public String getSessionDynamicCode(@PathVariable int sessionId) {
		return sessionRepository.findById(sessionId).map(Session::getDynamicCode).orElse("Session not found");
	}

	@GetMapping("/lecturer/createSession")
	public String showCreateSession() {
		return "createSession";
	}

	@GetMapping("/lecturer/addUser")
	public String showAddUser() {
		return "addUser";
	}
}
