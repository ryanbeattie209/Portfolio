package com.example.rrp.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.rrp.model.Attendance;
import com.example.rrp.model.Session;
import com.example.rrp.model.User;
import com.example.rrp.repo.AttendanceRepository;
import com.example.rrp.repo.SessionRepository;
import com.example.rrp.repo.UserRepository;

@Service
public class AttendanceServiceImpl implements AttendanceService {

	@Autowired
	private AttendanceRepository attendanceRepository;
	@Autowired
	private SessionRepository sessionRepository;
	@Autowired
	private UserRepository userRepository;

	/**
	 *Records Attendance into database using Username Module Code, Dynamic Code and Digits Entered by Student to Verify Attendance
	 */
	@Transactional
	public boolean recordAttendance(String username, String moduleCode, String dynamicCode, int digit1, int digit2) {
		Optional<Session> sessionOpt = sessionRepository.findActiveSessionByDynamicCode(dynamicCode);
		if (!sessionOpt.isPresent()) {
			return false;
		}
		Session session = sessionOpt.get();
		Optional<User> userOpt = userRepository.findById(username);
		if (userOpt.isEmpty()) {
			return false;
		}
		User user = userOpt.get();
		if (validateLibraryCardDigits(user.getLibraryCard(), session.getVerificationDigit1Index(),
				session.getVerificationDigit2Index(), digit1, digit2)) {
			Attendance attendance = new Attendance();
			attendance.setSession(session);
			attendance.setStudentUsername(username);
			attendance.setAttendanceTime(LocalDateTime.now());
			attendanceRepository.save(attendance);
			return true;
		} else {
			return false;
		}
	}

	
	private boolean validateLibraryCardDigits(String libraryCard, int index1, int index2, int digit1, int digit2) {
		if (libraryCard == null || libraryCard.length() <= Math.max(index1, index2)) {
			return false;
		}
		return (Character.getNumericValue(libraryCard.charAt(index1)) == digit1)
				&& (Character.getNumericValue(libraryCard.charAt(index2)) == digit2);
	}
}
