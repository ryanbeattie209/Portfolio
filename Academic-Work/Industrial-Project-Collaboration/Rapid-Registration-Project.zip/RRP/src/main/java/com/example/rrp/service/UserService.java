package com.example.rrp.service;

import com.example.rrp.model.User;
import com.example.rrp.model.Permission;
import com.example.rrp.repo.UserRepository;
import com.example.rrp.repo.PermissionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PermissionRepository permissionRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	
	/**
	 * @param username
	 * @param password
	 * @param roles
	 * @param libraryCard
	 * @return
	 * Creates User from inputed Param's
	 */
	public User createUser(String username, String password, List<String> roles, String libraryCard) {
		User user = new User();
		user.setUsername(username);
		user.setPassword(passwordEncoder.encode(password));
		user.setLibraryCard(libraryCard);
		List<Permission> permissions = new ArrayList<>();
		for (String role : roles) {
			permissions.add(permissionRepository.findByRoleName(role));
		}
		user.setPermissions(permissions);
		return userRepository.save(user);
	}
}
