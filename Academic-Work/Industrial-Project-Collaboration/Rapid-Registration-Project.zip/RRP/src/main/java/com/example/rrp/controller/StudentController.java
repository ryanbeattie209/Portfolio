package com.example.rrp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.rrp.model.Session;
import com.example.rrp.service.AttendanceService;
import com.example.rrp.service.SessionService;

@Controller
public class StudentController {

	@Autowired
	private SessionService sessionService;

	@Autowired
	private AttendanceService attendanceService;

	
	/**
	 * @param model
	 * @return
	 * Creates Student Dashboard with code form, digit form digit index's and module code 
	 */
	@GetMapping("/student/dashboard")
	
	public String studentDashboard(Model model) {
		try {
			Session currentSession = sessionService.getCurrentSession();
			model.addAttribute("showCodeForm", true);
			model.addAttribute("showDigitForm", false);
			model.addAttribute("digit1Index", currentSession.getVerificationDigit1Index() + 1);
			model.addAttribute("digit2Index", currentSession.getVerificationDigit2Index() + 1);
			model.addAttribute("moduleCode", currentSession.getModuleCode());
		} catch (Exception e) {
			model.addAttribute("error", "Failed to load session data: " + e.getMessage());
		}
		return "studentDashboard";
	}

	/**
	 * @param code
	 * @param model
	 * @param authentication
	 * @return
	 * Allows Student to join/register to module session by verifying inputed session code with inputed code
	 */
	@PostMapping("/student/verifySessionCode")
	
    public String verifySessionCode(@RequestParam("code") String code, Model model, Authentication authentication) {
        Session session = sessionService.verifyCodeAndGetSession(code);
        if (session != null) {
            model.addAttribute("showCodeForm", false);
            model.addAttribute("showDigitForm", true);
            model.addAttribute("moduleCode", session.getModuleCode());
            model.addAttribute("digit1Index", session.getVerificationDigit1Index() + 1);
            model.addAttribute("digit2Index", session.getVerificationDigit2Index() + 1);
            model.addAttribute("dynamicCode", code);
        } else {
            model.addAttribute("showCodeForm", true);
            model.addAttribute("showDigitForm", false);
            model.addAttribute("error", "Invalid code, please try again.");
        }
        return "studentDashboard";  // Refers to studentDashboard.html in your templates directory
    }

	/**
	 * @param moduleCode
	 * @param dynamicCode
	 * @param digit1
	 * @param digit2
	 * @param authentication
	 * @param model
	 * @return
	 * Registers Student Attendance 
	 */
	@PostMapping("/student/recordAttendance")
	
	public String recordAttendance(@RequestParam("moduleCode") String moduleCode,
			@RequestParam("dynamicCode") String dynamicCode, @RequestParam("digit1") int digit1,
			@RequestParam("digit2") int digit2, Authentication authentication, Model model) {
		if (authentication == null || !authentication.isAuthenticated()) {
			model.addAttribute("error", "You must be logged in to perform this action.");
			return "redirect:/login";
		}
		String username = authentication.getName();
		boolean isSuccess = attendanceService.recordAttendance(username, moduleCode, dynamicCode, digit1, digit2);
		if (isSuccess) {
			model.addAttribute("message", "Attendance recorded successfully.");
		} else {
			model.addAttribute("error", "Failed to record attendance. Check the digits and try again.");
		}
		return "studentDashboard";
	}
}
