package com.example.rrp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.example.rrp.security.JPARepositoryUserDetailsServiceImpl;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(securedEnabled = true)
public class SecurityConfiguration {

	@Autowired
	private JPARepositoryUserDetailsServiceImpl detailsService;

	@Bean
	UserDetailsService userDetails() {
		return detailsService;
	}

	@Bean
	PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}

	/**
	 * @param http
	 * @return
	 * @throws Exception
	 * Login Handlers checks whether login credentials are correct
	 */
	@Bean
	
	public SecurityFilterChain configure(HttpSecurity http) throws Exception {
		http.formLogin((form) -> form.loginPage("/login").loginProcessingUrl("/logincheck")
				.successHandler(authenticationSuccessHandler()).failureUrl("/login?error=1"))
				.logout((logout) -> logout.logoutRequestMatcher(new AntPathRequestMatcher("/logout", "GET")))
				.userDetailsService(detailsService);

		return http.build();
	}

	/**
	 * @return
	 * Login Redirector checks logged in user permissions and redirects based on role
	 */
	@Bean
	
	public AuthenticationSuccessHandler authenticationSuccessHandler() {
		return (request, response, authentication) -> {
			var authorities = authentication.getAuthorities();
			if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_LECTURER"))) {
				response.sendRedirect("/lecturer/createSession");
			} else if (authorities.stream().anyMatch(a -> a.getAuthority().equals("ROLE_STUDENT"))) {
				response.sendRedirect("/student/dashboard");
			} else {
				response.sendRedirect("/login");
			}
		};
	}
}
